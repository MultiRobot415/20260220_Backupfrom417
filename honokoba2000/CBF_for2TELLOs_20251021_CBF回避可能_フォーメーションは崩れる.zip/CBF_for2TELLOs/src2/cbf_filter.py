#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CBF filter module

Applies an obstacle-avoidance Control Barrier Function (CBF) as a minimal
modification to nominal inputs for the horizontal axes (proj X, proj Z),
using the test-coordinate formulation:
  - x_test corresponds to proj Z
  - y_test corresponds to proj X

The QP solved (analytically when possible):
  minimize 0.5 * ||u - u_nom||^2
  subject to a^T u + b >= 0  (CBF half-space)
             u_min <= u <= u_max (box bounds)

Where u = [u_x, u_y] in test coordinates.

We avoid external solvers: project onto the feasible set with simple steps.
If infeasible or numerically problematic, we fall back to clipping.

Author: Cascade
Created: 2025-08-26
"""
from typing import Tuple, Dict
import math

import numpy as np


class CBFParams:
    def __init__(self, K1=0.009, K2=0.009, alpha1=1.0, alpha2=1.0, alpha3=1.0, Delta=0.4,
                 u_min=-30.0, u_max=30.0):
        self.K1 = K1
        self.K2 = K2
        self.alpha1 = alpha1
        self.alpha2 = alpha2
        self.alpha3 = alpha3
        self.Delta = Delta
        self.u_min = u_min
        self.u_max = u_max


def cbf_halfspace_coeffs(x: float, y: float, x_dot: float, y_dot: float,
                         x_o: float, y_o: float, p: CBFParams) -> Tuple[np.ndarray, float]:
    """
    Compute half-space coefficients a, b for constraint a^T u + b >= 0
    using the provided CBF inequality in test coordinates.
    a = [2*K1*(x-x_o), 2*K2*(y-y_o)]
    b = 2 x_dot^2 + 2(α2+α3)(x−x_o)x_dot + 2 y_dot^2 + 2(α2+α3)(y−y_o)y_dot
        + α1α2[(x−x_o)^2 + (y−y_o)^2 − Δ^2]
    """
    dx = x - x_o
    dy = y - y_o
    a = np.array([2.0 * p.K1 * dx, 2.0 * p.K2 * dy], dtype=float)
    b = (
        2.0 * (x_dot ** 2) + 2.0 * (p.alpha2 + p.alpha3) * dx * x_dot
        + 2.0 * (y_dot ** 2) + 2.0 * (p.alpha2 + p.alpha3) * dy * y_dot
        + p.alpha1 * p.alpha2 * (dx * dx + dy * dy - p.Delta * p.Delta)
    )
    return a, b


def project_onto_box(u: np.ndarray, u_min: float, u_max: float) -> np.ndarray:
    return np.clip(u, u_min, u_max)


def project_onto_halfspace(u_nom: np.ndarray, a: np.ndarray, b: float) -> np.ndarray:
    """
    Euclidean projection of u_nom onto the half-space {u | a^T u + b >= 0}.
    If already feasible, returns u_nom.
    """
    aTa = float(a @ a)
    if aTa <= 1e-12:
        return u_nom.copy()
    margin = float(a @ u_nom + b)
    if margin >= 0.0:
        return u_nom.copy()
    # Move along a to satisfy a^T u + b = 0
    return u_nom - (margin / aTa) * a


def enforce_cbf(u_nom: Tuple[float, float],
                state_test: Tuple[float, float, float, float],
                obstacle_test: Tuple[float, float],
                params: CBFParams = None) -> Tuple[np.ndarray, Dict]:
    """
    Apply the CBF inequality to adjust u_nom minimally.

    Inputs:
      - u_nom: (u_x, u_y) in test coordinates
      - state_test: (x, y, x_dot, y_dot) in test coordinates
      - obstacle_test: (x_o, y_o) in test coordinates
      - params: CBFParams. If None, defaults are used.

    Returns: (u_safe (2,), info dict)
      info: {
        'feasible_nom': bool,
        'projected': bool,
        'fell_back': bool,
        'margin_before': float,
        'margin_after': float
      }
    """
    if params is None:
        params = CBFParams()

    u_nom = np.array(u_nom, dtype=float)
    x, y, x_dot, y_dot = state_test
    x_o, y_o = obstacle_test

    a, b = cbf_halfspace_coeffs(x, y, x_dot, y_dot, x_o, y_o, params)
    # Start with bound-clipped nominal
    u = project_onto_box(u_nom, params.u_min, params.u_max)

    info = {
        'feasible_nom': False,
        'projected': False,
        'fell_back': False,
        'margin_before': float(a @ u_nom + b),
        'margin_after': None,
    }

    # If nominal (unclipped) already satisfies CBF and bounds, return clipped within bounds
    margin_clipped = float(a @ u + b)
    if margin_clipped >= 0.0:
        info['feasible_nom'] = True
        info['margin_after'] = margin_clipped
        print(f"🟢 CBF: 名目入力が制約満足 margin={margin_clipped:.3f}")
        return u, info
    else:
        print(f"🔴 CBF: 名目入力が制約違反 margin={margin_clipped:.3f}, 修正が必要")

    # Project onto half-space then clip to box
    u_h = project_onto_halfspace(u, a, b)
    u_hc = project_onto_box(u_h, params.u_min, params.u_max)

    margin_hc = float(a @ u_hc + b)
    if margin_hc >= -1e-8:  # より厳密な許容誤差
        info['projected'] = True
        info['margin_after'] = margin_hc
        print(f"🟡 CBF: 半空間投影成功 margin={margin_hc:.6f}")
        return u_hc, info
    else:
        print(f"🟠 CBF: 半空間投影失敗 margin={margin_hc:.6f}, ライン探索を試行")

    # Try line search from box-clipped toward half-space projection
    direction = u_h - u
    denom = float(direction @ direction)
    if denom > 1e-12:
        # Find smallest t in [0,1] s.t. a^T (u + t d) + b >= 0
        num = -(float(a @ u + b))
        ad = float(a @ direction)
        t = 1.0 if abs(ad) < 1e-12 else max(0.0, min(1.0, num / ad))
        u_ls = u + t * direction
        u_ls = project_onto_box(u_ls, params.u_min, params.u_max)
        margin_ls = float(a @ u_ls + b)
        if margin_ls >= -1e-8:  # より厳密な許容誤差
            info['projected'] = True
            info['margin_after'] = margin_ls
            print(f"🟡 CBF: ライン探索成功 margin={margin_ls:.6f}")
            return u_ls, info
        else:
            print(f"🟠 CBF: ライン探索失敗 margin={margin_ls:.6f}")

    # As a last resort, move along +a direction from box-clipped u until feasible, respecting bounds
    # Compute maximum step before hitting bounds
    step = 0.0
    a_norm2 = float(a @ a)
    if a_norm2 > 1e-12:
        # required step s such that a^T (u + s a) + b = 0 -> s = -(a^T u + b)/||a||^2
        required = -(float(a @ u + b)) / a_norm2
        s = max(0.0, required)
        candidate = u + s * a
        candidate = project_onto_box(candidate, params.u_min, params.u_max)
        margin_candidate = float(a @ candidate + b)
        if margin_candidate >= -1e-8:  # より厳密な許容誤差
            info['projected'] = True
            info['margin_after'] = margin_candidate
            print(f"🟡 CBF: 方向探索成功 margin={margin_candidate:.6f}")
            return candidate, info
        else:
            print(f"🟠 CBF: 方向探索失敗 margin={margin_candidate:.6f}")

    # Fallback: return box-clipped u (may be infeasible). Caller should treat cautiously.
    final_margin = float(a @ u + b)
    info['fell_back'] = True
    info['margin_after'] = final_margin
    print(f"🔴 CBF: フォールバック - 制約違反 margin={final_margin:.6f} (INFEASIBLE)")
    return u, info
